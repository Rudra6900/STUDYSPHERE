<?php
session_start();
require 'db.php';
header('Content-Type: application/json');

$username = $_POST['username'] ?? '';
$password = $_POST['password'] ?? '';

if (empty($username) || empty($password)) {
    echo json_encode(['success' => false, 'message' => 'Username and password are required.']);
    exit;
}

// Check credentials
$stmt = $conn->prepare("SELECT * FROM users WHERE username = ?");
if (!$stmt) {
    echo json_encode(['success' => false, 'message' => 'Database error: ' . $conn->error]);
    exit;
}

$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0 && $user = $result->fetch_assoc()) {
    if (password_verify($password, $user['password'])) {

        if (isset($user['status']) && $user['status'] === 'banned') {
            echo json_encode(['success' => false, 'message' => 'Your account has been suspended.']);
            exit;
        }

        // Update last_login timestamp
        $updateStmt = $conn->prepare("UPDATE users SET last_login = NOW() WHERE id = ?");
        $updateStmt->bind_param("i", $user['id']);
        $updateStmt->execute();

        // Set Session Variables
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['username'] = $user['username'];

        if (isset($user['role']) && $user['role'] === 'teacher') {
            $_SESSION['teacher_logged_in'] = true;
        }

        echo json_encode(['success' => true, 'username' => $user['username'], 'role' => $user['role'] ?? 'student']);
    } else {
        echo json_encode(['success' => false, 'message' => 'Invalid username or password.']);
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid username or password.']);
}
?>
