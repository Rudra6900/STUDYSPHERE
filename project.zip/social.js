document.addEventListener('DOMContentLoaded', () => {
    const feed = document.querySelector('.feed');
    const postBtn = document.getElementById('post-btn');
    const postInput = document.getElementById('post-text');
    const postImageInput = document.getElementById('post-image-input');
    const uploadTrigger = document.getElementById('upload-trigger-btn');
    const imagePreviewContainer = document.getElementById('image-preview-container');
    const imagePreview = document.getElementById('image-preview');
    const removeImageBtn = document.getElementById('remove-image-btn');

    // Helper: Get User Data
    function getUserData() {
        return {
            username: localStorage.getItem('username') || 'Student User',
            avatar: localStorage.getItem('avatar') || '',
            major: localStorage.getItem('major') || 'Computer Science'
        };
    }

    // Helper: Render Avatar (Image or Initial)
    function getAvatarHTML(avatarUrl, initial) {
        if (avatarUrl) {
            return `<div class="avatar" style="background-image:url('${avatarUrl}'); background-size:cover; background-position:center; color:transparent;">${initial}</div>`;
        }
        return `<div class="avatar">${initial}</div>`;
    }

    // Helper: Render Small Avatar for Comments
    function getSmallAvatarHTML(avatarUrl, initial) {
        const style = avatarUrl ? `background-image:url('${avatarUrl}'); background-size:cover; background-position:center; color:transparent;` : '';
        return `<div class="comment-avatar" style="${style}">${avatarUrl ? '' : initial}</div>`;
    }

    // Helper: Create/Show Modal for Groups & Profile
    function showSocialModal(title, content) {
        let modal = document.getElementById('social-modal');
        if (!modal) {
            modal = document.createElement('div');
            modal.id = 'social-modal';
            modal.style.cssText = 'position:fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.5); display:flex; justify-content:center; align-items:center; z-index:2000; animation: fadeIn 0.2s;';
            modal.innerHTML = `
                <div style="background:white; padding:24px; border-radius:16px; width:90%; max-width:400px; position:relative; box-shadow:0 4px 20px rgba(0,0,0,0.2);">
                    <button style="position:absolute; top:12px; right:12px; border:none; background:none; font-size:20px; cursor:pointer; color:#666;" onclick="this.closest('#social-modal').style.display='none'">&times;</button>
                    <h3 id="soc-modal-title" style="margin-top:0; color:var(--accent); margin-bottom:16px;"></h3>
                    <div id="soc-modal-content" style="color:#444; line-height:1.5;"></div>
                </div>`;
            document.body.appendChild(modal);
            modal.addEventListener('click', (e) => { if(e.target === modal) modal.style.display = 'none'; });
        }
        modal.querySelector('#soc-modal-title').textContent = title;
        modal.querySelector('#soc-modal-content').innerHTML = content;
        modal.style.display = 'flex';
    }

    // Initialize Profile Display
    const userData = getUserData();
    const sidebarUsername = document.getElementById('sidebar-username');
    const sidebarAvatar = document.getElementById('sidebar-avatar');
    const sidebarMajor = document.getElementById('sidebar-major');

    if (sidebarUsername) sidebarUsername.textContent = userData.username;
    if (sidebarMajor) sidebarMajor.textContent = userData.major;
    if (sidebarAvatar) {
        if (userData.avatar) {
            sidebarAvatar.style.backgroundImage = `url('${userData.avatar}')`;
            sidebarAvatar.style.backgroundSize = 'cover';
            sidebarAvatar.style.color = 'transparent';
        }
    }

    // 0. Image Upload Preview
    if (uploadTrigger && postImageInput) {
        uploadTrigger.addEventListener('click', () => postImageInput.click());
        
        postImageInput.addEventListener('change', function() {
            const file = this.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    imagePreview.src = e.target.result;
                    imagePreviewContainer.style.display = 'block';
                }
                reader.readAsDataURL(file);
            }
        });

        removeImageBtn.addEventListener('click', () => {
            postImageInput.value = '';
            imagePreviewContainer.style.display = 'none';
            imagePreview.src = '';

            // Add Notification Badge to Social Menu Link
            const socialLink = document.querySelector('.menu .link[href="social.html"]') || document.querySelector('.menu .link.active');
            if (socialLink) {
                let badge = socialLink.querySelector('.notification-badge');
                if (!badge) {
                    badge = document.createElement('span');
                    badge.className = 'notification-badge';
                    socialLink.appendChild(badge);
                }
            }
        });
    }

    // 1. Post Functionality
    if (postBtn && postInput && feed) {
        postBtn.addEventListener('click', () => {
            const text = postInput.value.trim();
            const hasImage = imagePreviewContainer.style.display === 'block' && imagePreview.src;
            
            if (!text && !hasImage) return;

            const currentUser = getUserData();
            const userInitial = currentUser.username.charAt(0).toUpperCase();

            // Create new post element
            const newPost = document.createElement('div');
            newPost.className = 'post-card';
            newPost.innerHTML = `
                <div class="post-header">
                    ${getAvatarHTML(currentUser.avatar, userInitial)}
                    <div>
                        <div style="font-weight:600; color:#333">${currentUser.username}</div>
                        <div style="font-size:12px; color:gray">Just now</div>
                    </div>
                </div>
                <p class="post-content">${text.replace(/\n/g, '<br>')}</p>
                ${hasImage ? `<img src="${imagePreview.src}" class="post-media" alt="Post Image">` : ''}
                <div class="post-actions">
                    <button class="action-btn"><span class="material-symbols-rounded">thumb_up</span> <span class="like-count">0</span> Likes</button>
                    <button class="action-btn"><span class="material-symbols-rounded">comment</span> Comment</button>
                    <button class="action-btn"><span class="material-symbols-rounded">share</span> Share</button>
                </div>
                <div class="comments-section" style="display:none;">
                    <div class="comment-list"></div>
                    <div class="comment-input-area">
                        ${getAvatarHTML(currentUser.avatar, userInitial).replace('class="avatar"', 'class="avatar" style="width:32px; height:32px; font-size:14px;"')}
                        <input type="text" placeholder="Write a comment..." class="comment-input">
                    </div>
                </div>
            `;

            // Insert after the "Create Post" card (which is the first child)
            feed.insertBefore(newPost, feed.children[1]);
            postInput.value = ''; // Clear input
            
            // Clear image
            postImageInput.value = '';
            imagePreviewContainer.style.display = 'none';
            imagePreview.src = '';

            // Trigger Real-time Notification for other tabs
            localStorage.setItem('social_notification', JSON.stringify({ user: currentUser.username, action: 'posted', time: Date.now() }));
        });
    }

    // 2. Like Counter (Event Delegation)
    if (feed) {
        feed.addEventListener('click', (e) => {
            const btn = e.target.closest('.action-btn');
            if (!btn) return;

            // Check if it is the Like button
            const icon = btn.querySelector('.material-symbols-rounded');
            if (icon && icon.textContent.trim() === 'thumb_up') {
                const countSpan = btn.querySelector('.like-count');
                if (countSpan) {
                    let count = parseInt(countSpan.textContent);
                    
                    if (btn.classList.contains('liked')) {
                        count--; // Remove like
                        btn.classList.remove('liked');
                    } else {
                        count++; // Add like
                        btn.classList.add('liked');
                    }
                    countSpan.textContent = count;
                }
            }

            // Check if it is the Share button
            if (icon && icon.textContent.trim() === 'share') {
                const postCard = btn.closest('.post-card');
                const content = postCard.querySelector('.post-content').innerText;
                navigator.clipboard.writeText(content).then(() => {
                    const originalHTML = btn.innerHTML;
                    btn.innerHTML = '<span class="material-symbols-rounded">check</span> Copied';
                    btn.style.color = '#10b981';
                    setTimeout(() => {
                        btn.innerHTML = originalHTML;
                        btn.style.color = '';
                    }, 2000);
                });
            }

            // Check if it is the Comment button
            if (icon && icon.textContent.trim() === 'comment') {
                const postCard = btn.closest('.post-card');
                const commentSection = postCard.querySelector('.comments-section');
                if (commentSection) {
                    commentSection.style.display = commentSection.style.display === 'none' ? 'block' : 'none';
                    // Focus input if opening
                    if (commentSection.style.display === 'block') {
                        const input = commentSection.querySelector('input');
                        if(input) input.focus();
                    }
                }
            }
        });

        // Handle Comment Input (Enter key)
        feed.addEventListener('keypress', (e) => {
            if (e.target.classList.contains('comment-input') && e.key === 'Enter') {
                const text = e.target.value.trim();
                if (!text) return;
                
                const currentUser = getUserData();
                const userInitial = currentUser.username.charAt(0).toUpperCase();

                const list = e.target.closest('.comments-section').querySelector('.comment-list');
                const newComment = document.createElement('div');
                newComment.className = 'comment';
                newComment.innerHTML = `
                    ${getSmallAvatarHTML(currentUser.avatar, userInitial)}
                    <div class="comment-bubble"><strong>${currentUser.username}:</strong> ${text}</div>
                `;
                list.appendChild(newComment);
                e.target.value = '';
            }
        });
    }

    // 3. Sidebar Interactions (Profile & Groups)
    const profileCard = document.querySelector('.social-sidebar .card:first-child');
    if (profileCard) {
        profileCard.style.cursor = 'pointer';
        profileCard.addEventListener('click', () => {
            const currentUser = getUserData();
            const avatarStyle = currentUser.avatar ? `background-image:url('${currentUser.avatar}'); background-size:cover; background-position:center; color:transparent;` : 'background:var(--accent); color:white;';
            
            // Get Badges
            const badges = JSON.parse(localStorage.getItem('user-badges') || '[]');
            const badgesMap = {
                'quiz-master': { icon: '🧠', label: 'Quiz Master', color: '#8b5cf6' },
                'dedicated-learner': { icon: '⏱️', label: 'Dedicated Learner', color: '#10b981' },
                'note-taker': { icon: '📖', label: 'Scholar', color: '#f59e0b' }
            };
            const badgesHTML = badges.length ? badges.map(b => {
                const info = badgesMap[b] || { icon: '🏅', label: b, color: '#666' };
                return `<span class="badge" style="background:${info.color}20; color:${info.color}; border:1px solid ${info.color}40;">${info.icon} ${info.label}</span>`;
            }).join('') : '<span style="color:#999; font-size:13px;">No badges yet. Keep studying!</span>';

            showSocialModal('User Account', `
                <div style="text-align:center;">
                    <div class="avatar" style="width:80px; height:80px; font-size:32px; margin:0 auto 16px auto; display:grid; place-items:center; border-radius:50%; ${avatarStyle}">${currentUser.username.charAt(0).toUpperCase()}</div>
                    <div style="text-align:left; background:#f9fafb; padding:16px; border-radius:12px;">
                        <p style="margin:8px 0;"><strong>Username:</strong> ${currentUser.username}</p>
                        <p style="margin:8px 0;"><strong>Major:</strong> ${currentUser.major}</p>
                        <div style="margin:12px 0;"><strong>Badges:</strong><div style="display:flex; flex-wrap:wrap; gap:8px; margin-top:8px;">${badgesHTML}</div></div>
                        <p style="margin:8px 0;"><strong>Email:</strong> user@studysphere.edu</p>
                        <p style="margin:8px 0; display:flex; align-items:center; gap:8px;">
                            <strong>Password:</strong> 
                            <span id="pw-display">••••••••</span>
                            <span style="cursor:pointer; font-size:16px;" onclick="const el=document.getElementById('pw-display'); el.textContent = el.textContent==='••••••••' ? 'password123' : '••••••••'">👁️</span>
                        </p>
                    </div>
                </div>
            `);
        });
    }

    const groupItems = document.querySelectorAll('.social-sidebar ul li');
    groupItems.forEach(item => {
        item.style.cursor = 'pointer';
        item.addEventListener('click', () => {
            const groupName = item.textContent.trim();
            showSocialModal(groupName, `
                <div style="text-align:left; padding:0;">
                    <div style="height:100px; background:linear-gradient(to right, #4facfe 0%, #00f2fe 100%); border-radius:12px 12px 0 0; position:relative;">
                        <div style="width:60px; height:60px; background:white; border-radius:50%; position:absolute; bottom:-30px; left:20px; border:4px solid white; display:grid; place-items:center; font-size:24px;">👥</div>
                    </div>
                    <div style="padding:40px 20px 20px 20px;">
                        <h2 style="margin:0; color:var(--accent);">${groupName}</h2>
                        <p style="color:gray; font-size:14px; margin:5px 0 15px 0;">Public Group · 1.2k Members</p>
                        
                        <div style="display:flex; gap:10px; margin-bottom:15px;">
                            <button style="background:#e5e7eb; color:#333; border:none; padding:8px 16px; border-radius:6px; font-weight:600; cursor:pointer;">Joined</button>
                            <button style="background:var(--accent); color:white; border:none; padding:8px 16px; border-radius:6px; font-weight:600; cursor:pointer;">Group Chat</button>
                            <button style="background:transparent; border:1px solid #ddd; color:#666; padding:8px 16px; border-radius:6px; font-weight:600; cursor:pointer;">Invite</button>
                        </div>

                        <h4 style="margin:10px 0; border-bottom:1px solid #eee; padding-bottom:5px;">Group Chat</h4>
                        <div style="background:#f9fafb; border:1px solid #eee; border-radius:12px; padding:15px; height:200px; overflow-y:auto; display:flex; flex-direction:column; gap:10px; margin-bottom:10px;">
                            <div style="align-self:flex-start; background:white; padding:8px 12px; border-radius:12px; border:1px solid #eee; font-size:13px; max-width:80%;">
                                <strong style="color:var(--accent); display:block; font-size:11px; margin-bottom:2px;">Alice</strong>
                                Has anyone started the assignment?
                            </div>
                            <div style="align-self:flex-end; background:#dbeafe; padding:8px 12px; border-radius:12px; font-size:13px; max-width:80%;">
                                <strong style="color:#1e40af; display:block; font-size:11px; margin-bottom:2px;">You</strong>
                                Not yet, planning to start tonight.
                            </div>
                             <div style="align-self:flex-start; background:white; padding:8px 12px; border-radius:12px; border:1px solid #eee; font-size:13px; max-width:80%;">
                                <strong style="color:var(--accent); display:block; font-size:11px; margin-bottom:2px;">Bob</strong>
                                I found a great resource for question 3.
                            </div>
                        </div>
                        <div style="display:flex; gap:10px;">
                            <input type="text" placeholder="Type a message..." style="flex:1; padding:10px; border:1px solid #ddd; border-radius:20px; outline:none;">
                            <button style="background:var(--accent); color:white; border:none; width:40px; height:40px; border-radius:50%; cursor:pointer; display:grid; place-items:center;"><span class="material-symbols-rounded" style="font-size:20px;">send</span></button>
                        </div>
                    </div>
                </div>
            `);
        });
    });

    // 4. Leaderboard Population
    const leaderboardList = document.getElementById('leaderboard-list');
    if (leaderboardList) {
        // Dummy data mixed with local user data
        const localScore = JSON.parse(localStorage.getItem('learning-zone') || '{}').score || 0;
        const localTime = parseInt(localStorage.getItem('study-minutes') || '0');
        const currentUser = getUserData();

        const users = [
            { name: 'Sarah Lee', score: 18, time: 120, avatar: '', color: '#8b5cf6' },
            { name: 'Mike Chen', score: 15, time: 95, avatar: '', color: '#f59e0b' },
            { name: 'Alex J.', score: 12, time: 45, avatar: '', color: '#10b981' },
            { name: currentUser.username, score: localScore, time: localTime, avatar: currentUser.avatar, isMe: true }
        ];

        // Sort by score desc, then time desc
        users.sort((a, b) => b.score - a.score || b.time - a.time);

        leaderboardList.innerHTML = users.map((u, i) => {
            const avatarHTML = u.avatar 
                ? `<div style="width:32px; height:32px; border-radius:50%; background-image:url('${u.avatar}'); background-size:cover;"></div>`
                : `<div style="width:32px; height:32px; border-radius:50%; background:${u.color || 'var(--accent)'}; color:white; display:grid; place-items:center; font-size:12px; font-weight:bold;">${u.name.charAt(0)}</div>`;
            
            return `
                <div style="display:flex; align-items:center; gap:10px; padding:8px; border-radius:8px; background:${u.isMe ? '#f0f9ff' : 'transparent'}; border:${u.isMe ? '1px solid #bae6fd' : 'none'}">
                    <div style="font-weight:bold; color:#888; width:20px;">${i + 1}</div>
                    ${avatarHTML}
                    <div style="flex:1; font-size:14px; font-weight:${u.isMe ? '600' : '400'}">${u.name} ${u.isMe ? '(You)' : ''}</div>
                    <div style="text-align:right; font-size:12px; color:#666;"><div>${u.score} pts</div><div>${u.time}m</div></div>
                </div>
            `;
        }).join('');
    }

    // 5. Real-time Notification Listener
    window.addEventListener('storage', (e) => {
        if (e.key === 'social_notification' && e.newValue) {
            const data = JSON.parse(e.newValue);
            const currentUser = getUserData();
            // Show notification if it's from another user (or another tab)
            if (data.user) {
                const notif = document.createElement('div');
                notif.innerHTML = `
                    <div style="display:flex; align-items:center; gap:10px;">
                        <span class="material-symbols-rounded" style="color:var(--accent)">notifications_active</span>
                        <div><strong>${data.user}</strong> just ${data.action} something!</div>
                    </div>`;
                notif.style.cssText = 'position:fixed; bottom:80px; right:20px; background:var(--menu-bg); backdrop-filter:blur(10px); border:1px solid var(--border); padding:12px 20px; border-radius:12px; box-shadow:0 10px 30px rgba(0,0,0,0.2); z-index:2000; transform:translateY(20px); opacity:0; transition:all 0.3s ease; color:var(--text);';
                document.body.appendChild(notif);
                requestAnimationFrame(() => { notif.style.transform = 'translateY(0)'; notif.style.opacity = '1'; });
                setTimeout(() => { notif.style.opacity='0'; notif.style.transform='translateY(10px)'; setTimeout(()=>notif.remove(), 300); }, 4000);
            }
        }
    });
});