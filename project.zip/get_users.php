<?php
session_start();
require 'db.php';
header('Content-Type: application/json');

// Get JSON input for Admin actions (Ban/Delete)
$input = json_decode(file_get_contents('php://input'), true);

// --- ADMIN LOGIC ---
if (isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true) {
    
    // Handle POST actions (Ban/Delete)
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $action = $input['action'] ?? '';
        $id = $input['id'] ?? 0;

        if ($action === 'delete') {
            $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            echo json_encode(['success' => true]);
            exit;
        } elseif ($action === 'toggle_ban') {
            // Toggle status between 'active' and 'banned'
            $stmt = $conn->prepare("UPDATE users SET status = IF(status='banned', 'active', 'banned') WHERE id = ?");
            $stmt->bind_param("i", $id);
            $stmt->execute();
            echo json_encode(['success' => true]);
            exit;
        }
    }

    // Admin View: Fetch ALL users
    $result = $conn->query("SELECT * FROM users");
    echo json_encode($result->fetch_all(MYSQLI_ASSOC));
    exit;
}

// --- TEACHER LOGIC (RESTRICTED) ---
if (isset($_SESSION['teacher_logged_in']) && $_SESSION['teacher_logged_in'] === true) {
    // Teachers do not have access to the full user list anymore.
    echo json_encode([]);
    exit;
}

// --- UNAUTHORIZED ---
http_response_code(403);
echo json_encode(['error' => 'Access Denied']);
?>