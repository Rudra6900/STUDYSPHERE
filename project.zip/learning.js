const FLASHCARDS = [
    { term: 'HTML', def: 'Standard markup language for documents designed to be displayed in a web browser.' },
    { term: 'CSS', def: 'Style sheet language used for describing the presentation of a document written in a markup language.' },
    { term: 'JavaScript', def: 'Programming language that conforms to the ECMAScript specification.' },
    { term: 'DOM', def: 'Document Object Model - a cross-platform and language-independent interface that treats an XML or HTML document as a tree structure.' },
    { term: 'API', def: 'Application Programming Interface - a connection between computers or between computer programs.' }
];

let currentCardIdx = 0;

/* Flashcard Logic */
function renderFlashcard() {
    const card = FLASHCARDS[currentCardIdx];
    // Reset flip state
    document.getElementById('flashcard-inner').style.transform = 'rotateY(0deg)';
    
    // Update content (delayed slightly if flipping back to avoid seeing change)
    setTimeout(() => {
        document.getElementById('fc-front').textContent = card.term;
        document.getElementById('fc-back').textContent = card.def;
        document.getElementById('fc-progress').textContent = `${currentCardIdx + 1} / ${FLASHCARDS.length}`;
    }, 200);
}

function flipCard() {
    const inner = document.getElementById('flashcard-inner');
    const current = inner.style.transform;
    inner.style.transform = current === 'rotateY(180deg)' ? 'rotateY(0deg)' : 'rotateY(180deg)';
}

function nextCard() {
    if (currentCardIdx < FLASHCARDS.length - 1) { currentCardIdx++; renderFlashcard(); }
}

function prevCard() {
    if (currentCardIdx > 0) { currentCardIdx--; renderFlashcard(); }
}

// Initialize Flashcards on load
renderFlashcard();