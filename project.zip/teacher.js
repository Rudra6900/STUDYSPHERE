document.addEventListener('DOMContentLoaded', () => {
    // API Base Logic
    // Using relative paths. Ensure you are running on XAMPP (Port 80).
    const API_BASE = (window.location.port === '5500') ? 'http://localhost/practice/' : '';

    // Assignment Modal Logic
    const assignModal = document.getElementById('assignment-modal');
    const assignBtn = document.getElementById('create-assignment-btn');
    const assignForm = document.getElementById('assignment-form');

    if (assignBtn && assignModal) {
        assignBtn.onclick = () => assignModal.style.display = "block";
    }

    // Poll Modal Logic
    const pollModal = document.getElementById('poll-modal');
    const pollBtn = document.getElementById('create-poll-btn');
    const pollForm = document.getElementById('poll-form');
    
    // Poll Results Logic
    const resultsModal = document.getElementById('poll-results-modal');
    let currentPollVotes = [];

    if (pollBtn && pollModal) {
        pollBtn.onclick = () => pollModal.style.display = "block";
    }

    if (pollForm) {
        pollForm.onsubmit = (e) => {
            e.preventDefault();
            const question = pollForm.querySelector('input[name="question"]').value;
            const options = Array.from(pollForm.querySelectorAll('input[name="option"]'))
                                 .map(input => input.value.trim())
                                 .filter(val => val !== '');
            
            if (!question || options.length < 2) {
                alert('Please provide a question and at least two options.');
                return;
            }
            
            // Initialize votes
            currentPollVotes = new Array(options.length).fill(0);
            
            // Save poll data
            localStorage.setItem('live_poll_data', JSON.stringify({ id: 'poll_' + Date.now(), question, options }));
            
            alert('Poll has been sent to students!');
            pollModal.style.display = 'none';
            pollForm.reset();

            // Open Results Modal immediately
            if(resultsModal) {
                document.getElementById('result-question').textContent = question;
                updateResultsUI(options);
                resultsModal.style.display = 'block';
            }
        };
    }

    // Listen for votes
    window.addEventListener('storage', (e) => {
        if (e.key === 'poll_vote' && e.newValue) {
            const vote = JSON.parse(e.newValue);
            if (currentPollVotes[vote.optionIndex] !== undefined) {
                currentPollVotes[vote.optionIndex]++;
                
                // Get current options from the form (or saved state) to re-render
                // For simplicity, we assume the modal is open and we just update bars
                const barsContainer = document.getElementById('result-bars');
                if(barsContainer && barsContainer.children.length > 0) {
                    const totalVotes = currentPollVotes.reduce((a, b) => a + b, 0);
                    currentPollVotes.forEach((count, idx) => {
                        const percentage = totalVotes === 0 ? 0 : Math.round((count / totalVotes) * 100);
                        const barFill = document.getElementById(`bar-fill-${idx}`);
                        const barText = document.getElementById(`bar-text-${idx}`);
                        if(barFill) barFill.style.width = `${percentage}%`;
                        if(barText) barText.textContent = `${count} votes (${percentage}%)`;
                    });
                }
            }
        }
    });

    function updateResultsUI(options) {
        const container = document.getElementById('result-bars');
        container.innerHTML = options.map((opt, i) => `
            <div>
                <div style="display:flex; justify-content:space-between; margin-bottom:5px; font-size:0.9rem;">
                    <span>${opt}</span>
                    <span id="bar-text-${i}">0 votes (0%)</span>
                </div>
                <div style="background:rgba(255,255,255,0.1); height:10px; border-radius:5px; overflow:hidden;">
                    <div id="bar-fill-${i}" style="background:var(--accent); width:0%; height:100%; transition:width 0.3s;"></div>
                </div>
            </div>
        `).join('');
    }

    // Generic Close Logic for All Modals
    document.querySelectorAll('.close-modal').forEach(span => {
        span.onclick = function() {
            this.closest('.modal').style.display = "none";
        }
    });

    // Close when clicking outside any modal
    window.onclick = (event) => {
        if (event.target.classList.contains('modal')) {
            event.target.style.display = "none";
        }
    };

    if (assignForm) {
        assignForm.onsubmit = (e) => {
            e.preventDefault();
            alert('Assignment Created Successfully! (This is a demo)');
            assignModal.style.display = "none";
            assignForm.reset();
        }
    }
});

// Global function to open Report Modal
window.openReport = function(username) {
    const modal = document.getElementById('report-modal');
    const title = document.getElementById('report-title');
    const body = document.getElementById('report-body');
    
    if(modal && title && body) {
        title.textContent = `Progress Report: ${username}`;
        
        // Mock Data Visualization
        body.innerHTML = `
            <div style="display:grid; grid-template-columns:1fr 1fr; gap:15px; margin-bottom:20px;">
                <div style="background:rgba(255,255,255,0.05); padding:20px; border-radius:12px; text-align:center; border:1px solid rgba(255,255,255,0.1);">
                    <div style="color:#94a3b8; font-size:13px; margin-bottom:5px;">Average Grade</div>
                    <div style="font-size:28px; font-weight:bold; color:#3b82f6;">88%</div>
                </div>
                <div style="background:rgba(255,255,255,0.05); padding:20px; border-radius:12px; text-align:center; border:1px solid rgba(255,255,255,0.1);">
                    <div style="color:#94a3b8; font-size:13px; margin-bottom:5px;">Attendance</div>
                    <div style="font-size:28px; font-weight:bold; color:#10b981;">95%</div>
                </div>
            </div>
            
            <h4 style="color:#e2e8f0; margin-bottom:12px; border-bottom:1px solid rgba(255,255,255,0.1); padding-bottom:8px;">Recent Activity</h4>
            <ul style="list-style:none; padding:0; color:#cbd5e1; font-size:14px;">
                <li style="padding:10px 0; border-bottom:1px solid rgba(255,255,255,0.05); display:flex; justify-content:space-between; align-items:center;">
                    <span><i class='bx bxs-file-html' style="color:#e34f26; margin-right:8px;"></i> HTML Basics Quiz</span> 
                    <span style="background:rgba(16, 185, 129, 0.2); color:#34d399; padding:2px 8px; border-radius:4px; font-size:12px;">90%</span>
                </li>
                <li style="padding:10px 0; border-bottom:1px solid rgba(255,255,255,0.05); display:flex; justify-content:space-between; align-items:center;">
                    <span><i class='bx bxs-file-css' style="color:#264de4; margin-right:8px;"></i> CSS Flexbox</span> 
                    <span style="background:rgba(245, 158, 11, 0.2); color:#fbbf24; padding:2px 8px; border-radius:4px; font-size:12px;">75%</span>
                </li>
                <li style="padding:10px 0; display:flex; justify-content:space-between; align-items:center;">
                    <span><i class='bx bxs-file-js' style="color:#f7df1e; margin-right:8px;"></i> JS Intro</span> 
                    <span style="background:rgba(59, 130, 246, 0.2); color:#60a5fa; padding:2px 8px; border-radius:4px; font-size:12px;">Pending</span>
                </li>
            </ul>
            
            <button style="width:100%; margin-top:20px; padding:12px; background:var(--accent); color:white; border:none; border-radius:8px; cursor:pointer; font-weight:600;" onclick="alert('Detailed PDF download started...')">Download Full Transcript</button>
        `;
        
        modal.style.display = 'block';
    }
};

// Listen for Student Interactions (Raise Hand)
window.addEventListener('storage', (e) => {
    if (e.key === 'teacher_notification' && e.newValue) {
        const data = JSON.parse(e.newValue);
        if (data.type === 'raise_hand') {
            showToast(`✋ <b>${data.student}</b> raised their hand in <b>${data.topic}</b>`);
        }
    }
});

function playNotificationSound() {
    try {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        if (!AudioContext) return;
        const ctx = new AudioContext();
        const osc = ctx.createOscillator();
        osc.type = 'sine';
        osc.frequency.setValueAtTime(900, ctx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(400, ctx.currentTime + 0.3);
        osc.connect(ctx.destination);
        osc.start();
        osc.stop(ctx.currentTime + 0.4);
    } catch (e) { console.error("Audio API error:", e); }
}

function showToast(html) {
    playNotificationSound();
    const toast = document.createElement('div');
    toast.innerHTML = html;
    toast.style.cssText = 'position:fixed; bottom:20px; right:20px; background:#1e293b; border:1px solid rgba(255,255,255,0.1); color:white; padding:15px 20px; border-radius:12px; box-shadow:0 10px 30px rgba(0,0,0,0.5); z-index:3000; animation:fadeInUp 0.3s; display:flex; align-items:center; gap:10px;';
    document.body.appendChild(toast);
    setTimeout(() => {
        toast.style.opacity = '0';
        setTimeout(() => toast.remove(), 300);
    }, 5000);
}

// Global Click Sound
document.addEventListener('click', function(e) {
    if (e.target.closest('button, a, .btn, .action-card, .card')) {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        if (AudioContext) {
            const ctx = new AudioContext();
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.type = 'sine';
            osc.frequency.setValueAtTime(300, ctx.currentTime);
            osc.frequency.exponentialRampToValueAtTime(200, ctx.currentTime + 0.1);
            gain.gain.setValueAtTime(0.1, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.1);
            osc.start();
            osc.stop(ctx.currentTime + 0.1);
        }
    }
});