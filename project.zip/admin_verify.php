<?php
ob_start();
error_reporting(0);
ini_set('display_errors', 0);

session_start();
header('Content-Type: application/json');
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Headers: Content-Type");
header("Access-Control-Allow-Methods: POST, OPTIONS");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    ob_end_clean();
    http_response_code(200);
    exit(0);
}

$input = file_get_contents("php://input");
$data = json_decode($input, true) ?? [];
$password = $data['password'] ?? '';

// List of valid admin codes
$valid_codes = [
    'RUDRA@2553',
    'PRITUSH12', 
    'CODER007',
    'admin123'
];

ob_clean();
if (in_array($password, $valid_codes)) {
    $_SESSION['admin_logged_in'] = true;
    echo json_encode(['success' => true]);
} else {
    echo json_encode(['success' => false]);
}
?>