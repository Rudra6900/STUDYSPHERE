const container = document.querySelector('.container');
// --- API CONFIGURATION ---
// Using relative paths to ensure compatibility with Port Forwarding / Tunnels.
// NOTE: This requires the site to be accessed via XAMPP (Port 80), not Live Server.
const API_BASE = (window.location.port === '5500') ? 'http://localhost/practice/' : '';
console.log('API_BASE set to:', API_BASE || 'Relative Path');

const LoginLink = document.querySelector('.SignInLink');
const RegisterLink = document.querySelector('.SignUpLink');

// --- TOGGLE LOGIN / REGISTER VIEW ---
if (RegisterLink) {
    RegisterLink.addEventListener('click', (e) => {
        e.preventDefault();
        if (container) container.classList.add('active');
    });
}

if (LoginLink) {
    LoginLink.addEventListener('click', (e) => {
        e.preventDefault();
        if (container) container.classList.remove('active');
    });
}

// --- FORGOT PASSWORD LOGIC ---
function forgotPassword(){
    const email = prompt('Please enter your email to receive a password reset link:');
    if(!email) return;
    const re = /\S+@\S+\.\S+/;
    if(!re.test(email)){
        alert('Please enter a valid email address.');
        return;
    }
    
    fetch(API_BASE + 'forgot_password.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: email })
    })
    .then(res => res.json())
    .then(data => {
        alert(data.message);
        if(data.debug_link) console.log("Debug Reset Link:", data.debug_link);
    })
    .catch(err => alert('Error sending request.'));
}
document.addEventListener('DOMContentLoaded', () => {
    // --- LOGIN FORM SUBMISSION ---
    const loginForm = document.querySelector('.form-box.Login form');
    if (loginForm) {
        loginForm.addEventListener('submit', function(e) {
            e.preventDefault();
            const username = document.getElementById('login-username').value;
            const password = document.getElementById('login-password').value;

            // Send to PHP Backend
            const formData = new FormData();
            formData.append('username', username);
            formData.append('password', password);

            fetch(API_BASE + 'login.php', { method: 'POST', body: formData })
                .then(response => response.text())
                .then(text => {
                    try {
                        return JSON.parse(text);
                    } catch (e) {
                        if (text.includes('<?php')) {
                            alert('Setup Error: PHP code is not executing.\n\nPlease ensure you are accessing this site via your Web Server (e.g., localhost/practice) and NOT via Live Server (127.0.0.1:5500).');
                            throw new Error('Server returned raw PHP');
                        }
                        throw new Error('Invalid Server Response: ' + text.substring(0, 100));
                    }
                })
                .then(data => {
                    if (data.success) {
                        localStorage.setItem('username', data.username);
                        localStorage.setItem('isNewUser', 'true');
                        if (data.role === 'teacher') {
                            window.location.href = 'teacher_dashboard.html';
                        } else {
                            window.location.href = 'front.html';
                        }
                    } else {
                        alert(data.message);
                    }
                })
                .catch(err => {
                    console.error('Error:', err);
                    alert('Login Error: ' + err.message);
                });
        });
    }

    // --- REGISTER FORM SUBMISSION ---
    const registerForm = document.querySelector('.form-box.Register form');
    if (registerForm) {
        registerForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            const username = document.getElementById('reg-username').value;
            const email = document.getElementById('reg-email').value;
            const password = document.getElementById('reg-password').value;
            const role = (e.submitter && e.submitter.value) ? e.submitter.value : 'student';

            if (!username || !email || !password) {
                alert('Please fill in all fields');
                return;
            }

            if (password.length < 8) {
                alert('Password must be at least 8 characters long.');
                return;
            }

            // Send to PHP Backend
            const formData = new FormData();
            formData.append('username', username);
            formData.append('email', email);
            formData.append('password', password);
            formData.append('role', role);
            
            fetch(API_BASE + 'register.php', { method: 'POST', body: formData })
                .then(response => response.text())
                .then(text => {
                    try {
                        return JSON.parse(text);
                    } catch (e) {
                        if (text.includes('<?php')) {
                            alert('Setup Error: PHP code is not executing.\n\nPlease ensure you are accessing this site via your Web Server (e.g., localhost/practice) and NOT via Live Server (127.0.0.1:5500).');
                            throw new Error('Server returned raw PHP');
                        }
                        throw new Error('Invalid Server Response: ' + text.substring(0, 100));
                    }
                })
                .then(data => {
                    if (data.success) {
                        localStorage.setItem('username', username);
                        localStorage.setItem('isNewUser', 'true');
                        alert('Registration successful!');
                        if (role === 'teacher') {
                            window.location.href = 'teacher_dashboard.html';
                        } else {
                            window.location.href = 'front.html';
                        }
                    } else {
                        alert(data.message || 'Registration failed');
                    }   

                })
                .catch(err => {
                    console.error('Error:', err);
                    alert('Network error: ' + err.message);
                });
        });
    }

    // --- PASSWORD VISIBILITY TOGGLE ---
    const eye = document.getElementById('eyeball');
    const passwordInput = document.querySelector('.form-box.Login input[type="password"]');

    if (eye && passwordInput) {
        eye.addEventListener('click', e => {
            e.preventDefault();
            const isShown = document.body.classList.toggle('show-password');
            passwordInput.type = passwordInput.type === 'password' ? 'text' : 'password';
            eye.setAttribute('aria-pressed', String(isShown));
            eye.setAttribute('aria-label', isShown ? 'Hide password' : 'Show password');
            passwordInput.focus();
        });
    }

    // Attach forgot-password link handler (replaces inline onclick)
    const forgotLink = document.getElementById('forgot-link');
    if (forgotLink) {
        forgotLink.addEventListener('click', function(e) {
            e.preventDefault();
            forgotPassword();
        });
    }

    // --- FLASHLIGHT BEAM EFFECT ---
    const beam = document.getElementById('beam');
    // limit beam movement to a small range and smooth transitions
    const MAX_BEAM_DEG = 6; // maximum degrees the beam will rotate (±8°)
    let lastBeamDeg = 0;
    function updateBeamAngle(e) {
        if (!document.body.classList.contains('show-password')) return;
        if (!eye || !beam) return;
        const rect = eye.parentElement.getBoundingClientRect();
        const cx = rect.left + rect.width / 2;
        const cy = rect.top + rect.height / 2;
        const dx = e.clientX - cx;
        const dy = e.clientY - cy;
        let deg = Math.atan2(dy, dx) * 180 / Math.PI;
        // normalize to [-180, 180]
        if (deg > 180) deg -= 360;
        // clamp to a small range so beam only moves slightly
        const target = Math.max(-MAX_BEAM_DEG, Math.min(MAX_BEAM_DEG, deg));
        // smooth the movement (linear interpolation)
        lastBeamDeg = lastBeamDeg + (target - lastBeamDeg) * 0.18;
        document.documentElement.style.setProperty('--beamDegrees', lastBeamDeg + 'deg');
    }

    // keep listening; updateBeamAngle only acts when show-password is active
    document.addEventListener('mousemove', updateBeamAngle);

    // --- SECRET ADMIN ENTRY (Right-click Login) ---
    const loginBtn = document.querySelector('.form-box.Login .btn');
    if (loginBtn) {
        loginBtn.addEventListener('contextmenu', (e) => {
            e.preventDefault();
            const password = prompt("Enter Admin Password:");
            if (password) {
                fetch(API_BASE + 'admin_verify.php', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ password: password })
                })
                .then(res => res.text())
                .then(text => {
                    let data;
                    try {
                        data = JSON.parse(text);
                    } catch (e) {
                        if (text.includes('<?php')) {
                            alert('Setup Error: PHP code is not executing.');
                            throw new Error('Server returned raw PHP');
                        }
                        throw new Error('Invalid Server Response: ' + text.substring(0, 100));
                    }

                    if (data.success) {
                        window.location.href = 'admin.php';
                    } else {
                        alert('Access Denied');
                    }
                })
                .catch(err => {
                    console.error(err);
                    alert('Connection Error: ' + err.message);
                });
            }
        });
    }
});

// --- GLOBAL CLICK SOUND ---
document.addEventListener('click', function(e) {
    if (e.target.closest('button, a, .btn, .input-box')) {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        if (AudioContext) {
            const ctx = new AudioContext();
            const osc = ctx.createOscillator();
            const gain = ctx.createGain();
            osc.connect(gain);
            gain.connect(ctx.destination);
            osc.type = 'sine';
            osc.frequency.setValueAtTime(300, ctx.currentTime);
            osc.frequency.exponentialRampToValueAtTime(200, ctx.currentTime + 0.1);
            gain.gain.setValueAtTime(0.1, ctx.currentTime);
            gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.1);
            osc.start();
            osc.stop(ctx.currentTime + 0.1);
        }
    }
});