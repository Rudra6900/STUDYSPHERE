<?php
session_start();
if (!isset($_SESSION['teacher_logged_in']) || $_SESSION['teacher_logged_in'] !== true) {
    header("Location: index.html");
    exit;
}
include 'teacher_dashboard.html';
?>