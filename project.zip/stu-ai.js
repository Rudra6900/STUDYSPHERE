document.addEventListener('DOMContentLoaded', () => {
    const input = document.getElementById('user-input');
    const sendBtn = document.getElementById('send-btn');
    const chatWindow = document.getElementById('chat-window');
    const clearBtn = document.getElementById('clear-btn');
    const downloadBtn = document.getElementById('download-btn');
    const micBtn = document.getElementById('mic-btn');
    const stopGenContainer = document.getElementById('stop-gen-container');
    const stopGenBtn = document.getElementById('stop-gen-btn');

    // Load History
    let chatHistory = JSON.parse(localStorage.getItem('stu-ai-history') || '[]');

    function addMessage(text, sender, save = true) {
        const msgDiv = document.createElement('div');
        msgDiv.className = `message ${sender}`;
        
        const avatar = sender === 'bot' ? 'AI' : 'U';
        
        msgDiv.innerHTML = `
            <div class="msg-avatar">${avatar}</div>
            <div class="msg-bubble">${text}</div>
        `;
        
        chatWindow.appendChild(msgDiv);
        chatWindow.scrollTop = chatWindow.scrollHeight;

        // Add Copy Button to Code Blocks
        msgDiv.querySelectorAll('pre').forEach(pre => {
            if (pre.querySelector('.copy-btn')) return;
            
            const btn = document.createElement('button');
            btn.className = 'copy-btn';
            btn.innerHTML = '<span class="material-symbols-rounded" style="font-size:16px">content_copy</span>';
            btn.title = 'Copy Code';
            
            btn.addEventListener('click', () => {
                const code = pre.querySelector('code') ? pre.querySelector('code').innerText : pre.innerText;
                navigator.clipboard.writeText(code).then(() => {
                    btn.innerHTML = '<span class="material-symbols-rounded" style="font-size:16px">check</span>';
                    setTimeout(() => { btn.innerHTML = '<span class="material-symbols-rounded" style="font-size:16px">content_copy</span>'; }, 2000);
                });
            });
            pre.appendChild(btn);
        });

        // Add Actions for Bot Messages (TTS, Regenerate)
        if (sender === 'bot') {
            const actionsDiv = document.createElement('div');
            actionsDiv.className = 'msg-actions';
            
            // Text-to-Speech Button
            const ttsBtn = document.createElement('button');
            ttsBtn.className = 'msg-action-btn';
            ttsBtn.innerHTML = '<span class="material-symbols-rounded">volume_up</span>';
            ttsBtn.title = 'Read Aloud';
            ttsBtn.onclick = () => {
                const speech = new SpeechSynthesisUtterance(text.replace(/<[^>]*>/g, '')); // Strip HTML tags
                window.speechSynthesis.cancel(); // Stop previous
                window.speechSynthesis.speak(speech);
            };
            actionsDiv.appendChild(ttsBtn);

            // Regenerate Button
            const regenBtn = document.createElement('button');
            regenBtn.className = 'msg-action-btn regenerate-btn';
            regenBtn.innerHTML = '<span class="material-symbols-rounded">refresh</span>';
            regenBtn.title = 'Regenerate Response';
            regenBtn.onclick = () => {
                // Remove current message from DOM and History
                msgDiv.remove();
                if(chatHistory.length > 0 && chatHistory[chatHistory.length-1].text === text) {
                    chatHistory.pop();
                    localStorage.setItem('stu-ai-history', JSON.stringify(chatHistory));
                }
                // Trigger generation with last user message
                const lastMsg = chatHistory[chatHistory.length - 1];
                if (lastMsg && lastMsg.sender === 'user') {
                    generateResponse(lastMsg.text);
                }
            };
            actionsDiv.appendChild(regenBtn);
            msgDiv.appendChild(actionsDiv);

            // Update latest-bot class
            document.querySelectorAll('.message.bot').forEach(el => el.classList.remove('latest-bot'));
            msgDiv.classList.add('latest-bot');
        }

        if (save) {
            chatHistory.push({ text, sender });
            localStorage.setItem('stu-ai-history', JSON.stringify(chatHistory));
        }
    }

    function showTyping() {
        const typingDiv = document.createElement('div');
        typingDiv.className = 'message bot typing';
        typingDiv.id = 'typing-indicator';
        typingDiv.innerHTML = `
            <div class="msg-avatar">AI</div>
            <div class="typing-indicator"><div class="typing-dot"></div><div class="typing-dot"></div><div class="typing-dot"></div></div>
        `;
        chatWindow.appendChild(typingDiv);
        chatWindow.scrollTop = chatWindow.scrollHeight;
    }

    function removeTyping() {
        const el = document.getElementById('typing-indicator');
        if(el) el.remove();
    }

    let generationTimeout;

    function generateResponse(text) {
        showTyping();
        if(stopGenContainer) stopGenContainer.style.display = 'flex';
        generationTimeout = setTimeout(() => {
            removeTyping();
            if(stopGenContainer) stopGenContainer.style.display = 'none';
            const lowerText = text.toLowerCase();
            let response = "I'm still learning! Try asking about HTML, CSS, JavaScript, or Study Tips.";

            if (lowerText.includes('html')) {
                response = "HTML (HyperText Markup Language) is the standard markup language for creating web pages. It describes the structure of a Web page.";
            } else if (lowerText.includes('css')) {
                response = "CSS (Cascading Style Sheets) is used to style and layout web pages — for example, to alter the font, color, size, and spacing of your content.";
            } else if (lowerText.includes('javascript') || lowerText.includes('js')) {
                response = "JavaScript is a scripting language that enables you to create dynamically updating content. Example:<br><pre style='background:rgba(0,0,0,0.3); padding:10px; border-radius:8px; margin-top:5px; overflow-x:auto;'><code>console.log('Hello World');</code></pre>";
            } else if (lowerText.includes('hello') || lowerText.includes('hi')) {
                response = "Hello! I'm STU. Ready to help you ace your exams. What are we studying today?";
            }

            addMessage(response, 'bot');
        }, 1500);
    }

    if(stopGenBtn) {
        stopGenBtn.addEventListener('click', () => {
            clearTimeout(generationTimeout);
            removeTyping();
            if(stopGenContainer) stopGenContainer.style.display = 'none';
        });
    }

    function handleSend() {
        const text = input.value.trim();
        if (!text) return;
        addMessage(text, 'user');
        input.value = '';
        generateResponse(text);
    }

    sendBtn.addEventListener('click', handleSend);
    input.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') handleSend();
    });

    // Render History on Load
    function renderHistory() {
        chatWindow.innerHTML = '';
        if (chatHistory.length === 0) {
            addMessage("Hello! I'm STU, your AI study assistant. How can I help you with your coursework today?", 'bot');
        } else {
            chatHistory.forEach(msg => addMessage(msg.text, msg.sender, false));
        }
        // Ensure latest-bot class is applied after rendering history
        const botMsgs = chatWindow.querySelectorAll('.message.bot');
        if(botMsgs.length > 0) botMsgs[botMsgs.length - 1].classList.add('latest-bot');
    }
    renderHistory();

    // Clear Chat
    if (clearBtn) {
        clearBtn.addEventListener('click', () => {
            if (confirm('Are you sure you want to clear the chat history?')) {
                chatHistory = [];
                localStorage.removeItem('stu-ai-history');
                renderHistory();
            }
        });
    }

    // Download Chat
    if (downloadBtn) {
        downloadBtn.addEventListener('click', () => {
            if (chatHistory.length === 0) return alert('No chat history to download.');
            const content = chatHistory.map(msg => `[${msg.sender.toUpperCase()}] ${msg.text}`).join('\n\n');
            const blob = new Blob([content], { type: 'text/plain' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'stu-ai-chat.txt';
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
        });
    }

    // Voice Recognition
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (SpeechRecognition && micBtn) {
        const recognition = new SpeechRecognition();
        recognition.continuous = false;
        recognition.lang = 'en-US';

        micBtn.addEventListener('click', () => {
            if (micBtn.classList.contains('listening')) recognition.stop();
            else recognition.start();
        });

        recognition.onstart = () => { micBtn.classList.add('listening'); };
        recognition.onend = () => { micBtn.classList.remove('listening'); };
        recognition.onresult = (event) => {
            const transcript = event.results[0][0].transcript;
            input.value = transcript;
            input.focus();
        };
    } else if (micBtn) {
        micBtn.style.display = 'none';
    }
});